package com.example.motorgarage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ImageView aa =findViewById(R.id.imageView);
        ImageView a =findViewById(R.id.aa3);
        ImageView b =findViewById(R.id.imageView2);
        ImageView c =findViewById(R.id.imageView3);





        aa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent aa1 = new Intent(MainActivity2.this,MainActivity3.class);
            startActivity(aa1);
            }
        });


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a1 = new Intent(MainActivity2.this ,MainActivity5.class);
                startActivity(a1);
            }
        });


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b2 = new Intent(MainActivity2.this ,MainActivity4.class);
                startActivity(b2);
            }
        });


        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c3 = new Intent(MainActivity2.this ,MainActivity6.class);
                startActivity(c3);
            }
        });











    }
}